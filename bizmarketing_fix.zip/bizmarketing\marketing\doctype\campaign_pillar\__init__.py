# Campaign Pillar DocType
